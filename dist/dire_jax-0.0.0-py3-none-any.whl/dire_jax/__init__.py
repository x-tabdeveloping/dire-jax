
# dire-jax

"""
A JAX-based dimensionality reducer.
"""

from dire_jax.dire import *
from dire_jax.dire_utils import *

